import React, { useState } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';

const BusinessSection: React.FC = () => {
  const { t } = useLanguage();
  const [activeTab, setActiveTab] = useState(0);

  const businessLines = [
    {
      id: 'pharma',
      title: t('business.pharma'),
      description: t('business.pharma.desc'),
      image: 'https://d64gsuwffb70l.cloudfront.net/697a07882750ca11cca5ba96_1769605221012_6137a558.jpg',
      features: [
        'Distribusi obat resep dan OTC',
        'Sistem CDOB terintegrasi',
        'Cold chain untuk produk sensitif',
        'Tracking real-time pengiriman',
        'Jaringan apotek nasional',
        'Layanan 24/7 untuk produk darurat',
      ],
      stats: [
        { value: '5000+', label: 'SKU Produk' },
        { value: '10000+', label: 'Outlet Terlayani' },
        { value: '99.5%', label: 'On-Time Delivery' },
      ],
    },
    {
      id: 'medical',
      title: t('business.medical'),
      description: t('business.medical.desc'),
      image: 'https://d64gsuwffb70l.cloudfront.net/697a07882750ca11cca5ba96_1769605240285_94499a43.png',
      features: [
        'Alat diagnostik laboratorium',
        'Peralatan medis rumah sakit',
        'Consumable medis',
        'Sertifikasi CDAKB',
        'Layanan purna jual',
        'Training penggunaan alat',
      ],
      stats: [
        { value: '2000+', label: 'Jenis Alkes' },
        { value: '500+', label: 'Rumah Sakit' },
        { value: '100%', label: 'Compliance' },
      ],
    },
    {
      id: 'consumer',
      title: t('business.consumer'),
      description: t('business.consumer.desc'),
      image: 'https://d64gsuwffb70l.cloudfront.net/697a07882750ca11cca5ba96_1769605262600_4f1661f5.png',
      features: [
        'Produk vitamin & suplemen',
        'Skincare & kosmetik',
        'Personal care products',
        'Distribusi ke modern trade',
        'Distribusi ke traditional trade',
        'E-commerce fulfillment',
      ],
      stats: [
        { value: '3000+', label: 'SKU Produk' },
        { value: '15000+', label: 'Outlet' },
        { value: '34', label: 'Provinsi' },
      ],
    },
  ];

  return (
    <section id="business" className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="inline-block px-4 py-2 bg-blue-100 text-blue-700 rounded-full text-sm font-medium mb-4">
            {t('nav.business')}
          </span>
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
            {t('business.title')}
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Tiga lini bisnis utama yang mendukung ekosistem kesehatan Indonesia
          </p>
        </div>

        {/* Tab Navigation */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {businessLines.map((line, index) => (
            <button
              key={line.id}
              onClick={() => setActiveTab(index)}
              className={`px-6 py-3 rounded-xl font-medium transition-all duration-300 ${
                activeTab === index
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30'
                  : 'bg-white text-gray-700 hover:bg-gray-100 border border-gray-200'
              }`}
            >
              {line.title}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="bg-white rounded-3xl shadow-xl overflow-hidden">
          <div className="grid lg:grid-cols-2">
            {/* Image */}
            <div className="relative h-64 lg:h-auto">
              <img
                src={businessLines[activeTab].image}
                alt={businessLines[activeTab].title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent lg:bg-gradient-to-r"></div>
              <div className="absolute bottom-6 left-6 right-6 lg:hidden">
                <h3 className="text-2xl font-bold text-white">{businessLines[activeTab].title}</h3>
              </div>
            </div>

            {/* Content */}
            <div className="p-8 lg:p-12">
              <h3 className="text-2xl font-bold text-gray-900 mb-4 hidden lg:block">
                {businessLines[activeTab].title}
              </h3>
              <p className="text-gray-600 mb-8">{businessLines[activeTab].description}</p>

              {/* Features */}
              <div className="grid sm:grid-cols-2 gap-3 mb-8">
                {businessLines[activeTab].features.map((feature, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <div className="w-5 h-5 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <svg className="w-3 h-3 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                    <span className="text-gray-700 text-sm">{feature}</span>
                  </div>
                ))}
              </div>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-4 pt-8 border-t border-gray-100">
                {businessLines[activeTab].stats.map((stat, index) => (
                  <div key={index} className="text-center">
                    <div className="text-2xl font-bold text-blue-600">{stat.value}</div>
                    <div className="text-xs text-gray-500">{stat.label}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Additional Info Cards */}
        <div className="grid md:grid-cols-3 gap-6 mt-12">
          <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100">
            <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center mb-4">
              <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
              </svg>
            </div>
            <h4 className="text-lg font-semibold text-gray-900 mb-2">Standar Kualitas</h4>
            <p className="text-gray-600 text-sm">Semua lini bisnis beroperasi dengan standar kualitas tertinggi dan sertifikasi yang diakui.</p>
          </div>
          <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100">
            <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center mb-4">
              <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            </div>
            <h4 className="text-lg font-semibold text-gray-900 mb-2">Teknologi Modern</h4>
            <p className="text-gray-600 text-sm">Sistem distribusi terintegrasi dengan teknologi tracking dan monitoring real-time.</p>
          </div>
          <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100">
            <div className="w-12 h-12 bg-cyan-100 rounded-xl flex items-center justify-center mb-4">
              <svg className="w-6 h-6 text-cyan-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
              </svg>
            </div>
            <h4 className="text-lg font-semibold text-gray-900 mb-2">Tim Profesional</h4>
            <p className="text-gray-600 text-sm">Didukung oleh tim berpengalaman di bidang distribusi farmasi dan kesehatan.</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default BusinessSection;
