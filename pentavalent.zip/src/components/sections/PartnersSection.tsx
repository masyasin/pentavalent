import React, { useState, useEffect } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { supabase } from '../../lib/supabase';

interface Partner {
  id: string;
  name: string;
  logo_url: string;
  partner_type: string;
  website: string;
}

const PartnersSection: React.FC = () => {
  const { t } = useLanguage();
  const [partners, setPartners] = useState<Partner[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeFilter, setActiveFilter] = useState('all');

  useEffect(() => {
    fetchPartners();
  }, []);

  const fetchPartners = async () => {
    try {
      const { data, error } = await supabase
        .from('partners')
        .select('*')
        .eq('is_active', true)
        .order('sort_order');
      
      if (error) throw error;
      setPartners(data || []);
    } catch (error) {
      console.error('Error fetching partners:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredPartners = activeFilter === 'all' 
    ? partners 
    : partners.filter(p => p.partner_type === activeFilter);

  // Generate placeholder logos for partners
  const getPartnerInitials = (name: string) => {
    return name.split(' ').map(word => word[0]).join('').slice(0, 2).toUpperCase();
  };

  const partnerColors = [
    'bg-blue-600', 'bg-cyan-600', 'bg-green-600', 'bg-purple-600', 
    'bg-red-600', 'bg-orange-600', 'bg-pink-600', 'bg-indigo-600',
    'bg-teal-600', 'bg-yellow-600', 'bg-emerald-600', 'bg-rose-600'
  ];

  return (
    <section id="partners" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="inline-block px-4 py-2 bg-blue-100 text-blue-700 rounded-full text-sm font-medium mb-4">
            {t('nav.partners')}
          </span>
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
            {t('partners.title')}
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            {t('partners.subtitle')}
          </p>
        </div>

        {/* Filter Tabs */}
        <div className="flex justify-center gap-4 mb-12">
          {['all', 'principal', 'international'].map((filter) => (
            <button
              key={filter}
              onClick={() => setActiveFilter(filter)}
              className={`px-6 py-2 rounded-full font-medium transition-all ${
                activeFilter === filter
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              {filter === 'all' ? 'Semua' : filter === 'principal' ? 'Nasional' : 'Internasional'}
            </button>
          ))}
        </div>

        {/* Partners Grid */}
        {loading ? (
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-6">
            {[...Array(12)].map((_, i) => (
              <div key={i} className="bg-gray-100 rounded-2xl p-6 h-32 animate-pulse"></div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-6">
            {filteredPartners.map((partner, index) => (
              <div
                key={partner.id}
                className="bg-gray-50 rounded-2xl p-6 flex items-center justify-center hover:bg-white hover:shadow-lg hover:scale-105 transition-all duration-300 cursor-pointer group border border-transparent hover:border-blue-100"
                onClick={() => partner.website && window.open(partner.website, '_blank')}
              >
                <div className={`w-16 h-16 ${partnerColors[index % partnerColors.length]} rounded-xl flex items-center justify-center text-white font-bold text-lg group-hover:scale-110 transition-transform`}>
                  {getPartnerInitials(partner.name)}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Partner Stats */}
        <div className="mt-16 grid md:grid-cols-3 gap-8">
          <div className="text-center p-8 bg-gradient-to-br from-blue-50 to-cyan-50 rounded-2xl">
            <div className="text-4xl font-bold text-blue-600 mb-2">50+</div>
            <div className="text-gray-600">Principal Partners</div>
          </div>
          <div className="text-center p-8 bg-gradient-to-br from-green-50 to-emerald-50 rounded-2xl">
            <div className="text-4xl font-bold text-green-600 mb-2">20+</div>
            <div className="text-gray-600">International Partners</div>
          </div>
          <div className="text-center p-8 bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl">
            <div className="text-4xl font-bold text-purple-600 mb-2">10000+</div>
            <div className="text-gray-600">SKU Produk</div>
          </div>
        </div>

        {/* CTA */}
        <div className="mt-16 text-center">
          <div className="bg-gray-900 rounded-3xl p-8 md:p-12">
            <h3 className="text-2xl md:text-3xl font-bold text-white mb-4">
              Bergabung Sebagai Mitra
            </h3>
            <p className="text-gray-400 mb-8 max-w-2xl mx-auto">
              Jadilah bagian dari jaringan distribusi terbesar di Indonesia. 
              Kami siap membantu mengembangkan bisnis Anda ke seluruh nusantara.
            </p>
            <button className="px-8 py-4 bg-blue-600 text-white font-semibold rounded-xl hover:bg-blue-700 transition-colors">
              Hubungi Tim Partnership
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default PartnersSection;
