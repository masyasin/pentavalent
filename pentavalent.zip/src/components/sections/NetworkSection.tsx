import React, { useState, useEffect } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { supabase } from '../../lib/supabase';

interface Branch {
  id: string;
  name: string;
  branch_type: string;
  city: string;
  province: string;
  address: string;
  phone: string;
  latitude: number;
  longitude: number;
}

const NetworkSection: React.FC = () => {
  const { t } = useLanguage();
  const [branches, setBranches] = useState<Branch[]>([]);
  const [selectedProvince, setSelectedProvince] = useState<string>('all');
  const [selectedBranch, setSelectedBranch] = useState<Branch | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchBranches();
  }, []);

  const fetchBranches = async () => {
    try {
      const { data, error } = await supabase
        .from('branches')
        .select('*')
        .eq('is_active', true)
        .order('province');
      
      if (error) throw error;
      setBranches(data || []);
    } catch (error) {
      console.error('Error fetching branches:', error);
    } finally {
      setLoading(false);
    }
  };

  const provinces = ['all', ...new Set(branches.map(b => b.province))];
  
  const filteredBranches = selectedProvince === 'all' 
    ? branches 
    : branches.filter(b => b.province === selectedProvince);

  const branchCount = branches.filter(b => b.branch_type === 'branch' || b.branch_type === 'head_office').length;
  const depoCount = branches.filter(b => b.branch_type === 'depo').length;

  return (
    <section id="network" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="inline-block px-4 py-2 bg-blue-100 text-blue-700 rounded-full text-sm font-medium mb-4">
            {t('nav.network')}
          </span>
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
            {t('network.title')}
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            {t('network.subtitle')}
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-12">
          <div className="bg-gradient-to-br from-blue-600 to-blue-700 rounded-2xl p-6 text-white text-center">
            <div className="text-4xl font-bold mb-2">{branchCount}</div>
            <div className="text-blue-100">Cabang</div>
          </div>
          <div className="bg-gradient-to-br from-cyan-600 to-cyan-700 rounded-2xl p-6 text-white text-center">
            <div className="text-4xl font-bold mb-2">{depoCount}</div>
            <div className="text-cyan-100">Depo</div>
          </div>
          <div className="bg-gradient-to-br from-green-600 to-green-700 rounded-2xl p-6 text-white text-center">
            <div className="text-4xl font-bold mb-2">34</div>
            <div className="text-green-100">Provinsi</div>
          </div>
          <div className="bg-gradient-to-br from-purple-600 to-purple-700 rounded-2xl p-6 text-white text-center">
            <div className="text-4xl font-bold mb-2">100%</div>
            <div className="text-purple-100">Coverage</div>
          </div>
        </div>

        {/* Indonesia Map Visualization */}
        <div className="bg-gray-50 rounded-3xl p-8 mb-12">
          <div className="relative aspect-[2/1] bg-gradient-to-br from-blue-50 to-cyan-50 rounded-2xl overflow-hidden">
            {/* Simplified Indonesia Map SVG */}
            <svg viewBox="0 0 1000 500" className="w-full h-full">
              {/* Background */}
              <rect fill="#f0f9ff" width="1000" height="500"/>
              
              {/* Simplified Indonesia archipelago shapes */}
              {/* Sumatra */}
              <path d="M100,150 L150,100 L180,120 L200,180 L180,250 L150,300 L100,280 L80,220 Z" 
                fill="#0066CC" fillOpacity="0.3" stroke="#0066CC" strokeWidth="2"/>
              
              {/* Java */}
              <path d="M250,280 L350,260 L450,270 L480,290 L450,310 L350,320 L250,300 Z" 
                fill="#0066CC" fillOpacity="0.3" stroke="#0066CC" strokeWidth="2"/>
              
              {/* Kalimantan */}
              <path d="M350,100 L450,80 L500,120 L520,200 L480,250 L400,240 L350,180 Z" 
                fill="#0066CC" fillOpacity="0.3" stroke="#0066CC" strokeWidth="2"/>
              
              {/* Sulawesi */}
              <path d="M550,120 L600,100 L620,150 L600,200 L580,180 L560,220 L540,180 Z" 
                fill="#0066CC" fillOpacity="0.3" stroke="#0066CC" strokeWidth="2"/>
              
              {/* Papua */}
              <path d="M750,150 L850,120 L900,150 L920,200 L880,250 L800,240 L750,200 Z" 
                fill="#0066CC" fillOpacity="0.3" stroke="#0066CC" strokeWidth="2"/>
              
              {/* Bali & Nusa Tenggara */}
              <path d="M500,300 L520,290 L540,300 L560,295 L580,305 L600,300 L620,310 L600,320 L500,320 Z" 
                fill="#0066CC" fillOpacity="0.3" stroke="#0066CC" strokeWidth="2"/>
              
              {/* Maluku */}
              <path d="M680,180 L720,160 L740,200 L720,240 L680,220 Z" 
                fill="#0066CC" fillOpacity="0.3" stroke="#0066CC" strokeWidth="2"/>

              {/* Branch location dots */}
              {branches.slice(0, 20).map((branch, index) => {
                // Map coordinates to SVG viewBox
                const x = ((branch.longitude - 95) / 50) * 900 + 50;
                const y = ((-branch.latitude + 10) / 20) * 400 + 50;
                return (
                  <g key={branch.id}>
                    <circle
                      cx={x}
                      cy={y}
                      r={branch.branch_type === 'head_office' ? 12 : 8}
                      fill={branch.branch_type === 'head_office' ? '#dc2626' : branch.branch_type === 'depo' ? '#16a34a' : '#0066CC'}
                      className="cursor-pointer hover:opacity-80 transition-opacity"
                      onClick={() => setSelectedBranch(branch)}
                    >
                      <animate attributeName="r" values={branch.branch_type === 'head_office' ? '12;14;12' : '8;10;8'} dur="2s" repeatCount="indefinite"/>
                    </circle>
                    <circle
                      cx={x}
                      cy={y}
                      r={branch.branch_type === 'head_office' ? 18 : 14}
                      fill="none"
                      stroke={branch.branch_type === 'head_office' ? '#dc2626' : branch.branch_type === 'depo' ? '#16a34a' : '#0066CC'}
                      strokeWidth="2"
                      opacity="0.3"
                    >
                      <animate attributeName="r" values={branch.branch_type === 'head_office' ? '18;24;18' : '14;20;14'} dur="2s" repeatCount="indefinite"/>
                      <animate attributeName="opacity" values="0.3;0;0.3" dur="2s" repeatCount="indefinite"/>
                    </circle>
                  </g>
                );
              })}
            </svg>

            {/* Legend */}
            <div className="absolute bottom-4 left-4 bg-white/90 backdrop-blur-sm rounded-lg p-4 shadow-lg">
              <div className="flex items-center gap-6 text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 bg-red-600 rounded-full"></div>
                  <span>Kantor Pusat</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-blue-600 rounded-full"></div>
                  <span>Cabang</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-green-600 rounded-full"></div>
                  <span>Depo</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Branch List */}
        <div>
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
            <h3 className="text-xl font-semibold text-gray-900">Daftar Lokasi</h3>
            <select
              value={selectedProvince}
              onChange={(e) => setSelectedProvince(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="all">Semua Provinsi</option>
              {provinces.slice(1).map((province) => (
                <option key={province} value={province}>{province}</option>
              ))}
            </select>
          </div>

          {loading ? (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="bg-gray-100 rounded-xl p-6 animate-pulse">
                  <div className="h-4 bg-gray-200 rounded w-3/4 mb-3"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/2 mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded w-full"></div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredBranches.map((branch) => (
                <div
                  key={branch.id}
                  className={`bg-white rounded-xl p-6 border-2 transition-all cursor-pointer hover:shadow-lg ${
                    selectedBranch?.id === branch.id
                      ? 'border-blue-500 shadow-lg'
                      : 'border-gray-100 hover:border-blue-200'
                  }`}
                  onClick={() => setSelectedBranch(branch)}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h4 className="font-semibold text-gray-900">{branch.name}</h4>
                      <p className="text-sm text-gray-500">{branch.city}, {branch.province}</p>
                    </div>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      branch.branch_type === 'head_office'
                        ? 'bg-red-100 text-red-700'
                        : branch.branch_type === 'depo'
                        ? 'bg-green-100 text-green-700'
                        : 'bg-blue-100 text-blue-700'
                    }`}>
                      {branch.branch_type === 'head_office' ? 'HQ' : branch.branch_type === 'depo' ? 'Depo' : 'Branch'}
                    </span>
                  </div>
                  {branch.address && (
                    <p className="text-sm text-gray-600 mb-2">{branch.address}</p>
                  )}
                  {branch.phone && (
                    <div className="flex items-center gap-2 text-sm text-gray-500">
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                      </svg>
                      {branch.phone}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default NetworkSection;
