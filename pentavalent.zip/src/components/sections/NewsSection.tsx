import React, { useState, useEffect } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { supabase } from '../../lib/supabase';

interface NewsItem {
  id: string;
  title_id: string;
  title_en: string;
  slug: string;
  excerpt_id: string;
  excerpt_en: string;
  featured_image: string;
  category: string;
  published_at: string;
}

const NewsSection: React.FC = () => {
  const { t, language } = useLanguage();
  const [news, setNews] = useState<NewsItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedNews, setSelectedNews] = useState<NewsItem | null>(null);

  useEffect(() => {
    fetchNews();
  }, []);

  const fetchNews = async () => {
    try {
      const { data, error } = await supabase
        .from('news')
        .select('*')
        .eq('is_published', true)
        .order('published_at', { ascending: false })
        .limit(6);
      
      if (error) throw error;
      setNews(data || []);
    } catch (error) {
      console.error('Error fetching news:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString(language === 'id' ? 'id-ID' : 'en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  const categoryColors: { [key: string]: string } = {
    'award': 'bg-yellow-100 text-yellow-700',
    'expansion': 'bg-green-100 text-green-700',
    'investor': 'bg-blue-100 text-blue-700',
    'partnership': 'bg-purple-100 text-purple-700',
    'default': 'bg-gray-100 text-gray-700',
  };

  const categoryLabels: { [key: string]: string } = {
    'award': 'Penghargaan',
    'expansion': 'Ekspansi',
    'investor': 'Investor',
    'partnership': 'Kemitraan',
  };

  // Placeholder images for news
  const newsImages = [
    'https://d64gsuwffb70l.cloudfront.net/697a07882750ca11cca5ba96_1769605144011_b03c2175.png',
    'https://d64gsuwffb70l.cloudfront.net/697a07882750ca11cca5ba96_1769605148613_73ff68ae.png',
    'https://d64gsuwffb70l.cloudfront.net/697a07882750ca11cca5ba96_1769605146692_aa3de088.png',
  ];

  return (
    <section id="news" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="inline-block px-4 py-2 bg-blue-100 text-blue-700 rounded-full text-sm font-medium mb-4">
            {t('nav.news')}
          </span>
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
            {t('news.title')}
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            {t('news.subtitle')}
          </p>
        </div>

        {/* News Grid */}
        {loading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="bg-gray-100 rounded-2xl overflow-hidden animate-pulse">
                <div className="h-48 bg-gray-200"></div>
                <div className="p-6">
                  <div className="h-4 bg-gray-200 rounded w-1/4 mb-3"></div>
                  <div className="h-6 bg-gray-200 rounded w-3/4 mb-2"></div>
                  <div className="h-4 bg-gray-200 rounded w-full"></div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {news.map((item, index) => (
              <article
                key={item.id}
                className="bg-white rounded-2xl overflow-hidden shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-300 group cursor-pointer"
                onClick={() => setSelectedNews(item)}
              >
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={item.featured_image || newsImages[index % newsImages.length]}
                    alt={language === 'id' ? item.title_id : item.title_en}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute top-4 left-4">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${categoryColors[item.category] || categoryColors['default']}`}>
                      {categoryLabels[item.category] || item.category}
                    </span>
                  </div>
                </div>
                <div className="p-6">
                  <div className="flex items-center gap-2 text-sm text-gray-500 mb-3">
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                    {formatDate(item.published_at)}
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2 group-hover:text-blue-600 transition-colors line-clamp-2">
                    {language === 'id' ? item.title_id : item.title_en}
                  </h3>
                  <p className="text-gray-600 text-sm line-clamp-2 mb-4">
                    {language === 'id' ? item.excerpt_id : item.excerpt_en}
                  </p>
                  <button className="flex items-center gap-2 text-blue-600 font-medium text-sm group-hover:gap-3 transition-all">
                    {t('news.readmore')}
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                    </svg>
                  </button>
                </div>
              </article>
            ))}
          </div>
        )}

        {/* View All Button */}
        <div className="text-center mt-12">
          <button className="px-8 py-4 bg-gray-900 text-white font-semibold rounded-xl hover:bg-gray-800 transition-colors">
            Lihat Semua Berita
          </button>
        </div>

        {/* News Modal */}
        {selectedNews && (
          <div 
            className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
            onClick={() => setSelectedNews(null)}
          >
            <div 
              className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="relative h-64">
                <img
                  src={selectedNews.featured_image || newsImages[0]}
                  alt={language === 'id' ? selectedNews.title_id : selectedNews.title_en}
                  className="w-full h-full object-cover"
                />
                <button
                  onClick={() => setSelectedNews(null)}
                  className="absolute top-4 right-4 w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-lg hover:bg-gray-100"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
              <div className="p-8">
                <div className="flex items-center gap-4 mb-4">
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${categoryColors[selectedNews.category] || categoryColors['default']}`}>
                    {categoryLabels[selectedNews.category] || selectedNews.category}
                  </span>
                  <span className="text-sm text-gray-500">
                    {formatDate(selectedNews.published_at)}
                  </span>
                </div>
                <h2 className="text-2xl font-bold text-gray-900 mb-4">
                  {language === 'id' ? selectedNews.title_id : selectedNews.title_en}
                </h2>
                <p className="text-gray-600 leading-relaxed">
                  {language === 'id' ? selectedNews.excerpt_id : selectedNews.excerpt_en}
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};

export default NewsSection;
