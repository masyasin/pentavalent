import React from 'react';
import { useLanguage } from '../../contexts/LanguageContext';

const ManagementSection: React.FC = () => {
  const { language } = useLanguage();

  const management = [
    {
      name: 'Budi Santoso',
      position: language === 'id' ? 'Direktur Utama' : 'President Director',
      image: 'https://d64gsuwffb70l.cloudfront.net/697a07882750ca11cca5ba96_1769605162964_846014ea.jpg',
      bio: language === 'id' 
        ? 'Lebih dari 30 tahun pengalaman di industri distribusi farmasi.'
        : 'Over 30 years of experience in pharmaceutical distribution industry.',
    },
    {
      name: 'Siti Rahayu',
      position: language === 'id' ? 'Direktur Keuangan' : 'Finance Director',
      image: 'https://d64gsuwffb70l.cloudfront.net/697a07882750ca11cca5ba96_1769605191855_364fe96e.png',
      bio: language === 'id'
        ? 'Ahli keuangan dengan pengalaman di perusahaan multinasional.'
        : 'Finance expert with experience in multinational companies.',
    },
    {
      name: 'Ahmad Wijaya',
      position: language === 'id' ? 'Direktur Operasional' : 'Operations Director',
      image: 'https://d64gsuwffb70l.cloudfront.net/697a07882750ca11cca5ba96_1769605172731_c2cc6aba.png',
      bio: language === 'id'
        ? 'Spesialis logistik dan supply chain management.'
        : 'Logistics and supply chain management specialist.',
    },
    {
      name: 'Maya Putri',
      position: language === 'id' ? 'Direktur Komersial' : 'Commercial Director',
      image: 'https://d64gsuwffb70l.cloudfront.net/697a07882750ca11cca5ba96_1769605192539_f9f7ef16.jpg',
      bio: language === 'id'
        ? 'Pengalaman luas dalam pengembangan bisnis dan kemitraan.'
        : 'Extensive experience in business development and partnerships.',
    },
    {
      name: 'Hendra Kusuma',
      position: language === 'id' ? 'Direktur IT' : 'IT Director',
      image: 'https://d64gsuwffb70l.cloudfront.net/697a07882750ca11cca5ba96_1769605168697_1b64f642.png',
      bio: language === 'id'
        ? 'Ahli transformasi digital dan sistem informasi enterprise.'
        : 'Digital transformation and enterprise information systems expert.',
    },
    {
      name: 'Dewi Lestari',
      position: language === 'id' ? 'Direktur SDM' : 'HR Director',
      image: 'https://d64gsuwffb70l.cloudfront.net/697a07882750ca11cca5ba96_1769605194869_8d98ee9f.png',
      bio: language === 'id'
        ? 'Spesialis pengembangan organisasi dan talent management.'
        : 'Organization development and talent management specialist.',
    },
    {
      name: 'Rudi Hartono',
      position: language === 'id' ? 'Komisaris Utama' : 'President Commissioner',
      image: 'https://d64gsuwffb70l.cloudfront.net/697a07882750ca11cca5ba96_1769605172202_2825c200.png',
      bio: language === 'id'
        ? 'Pengusaha senior dengan pengalaman di berbagai industri.'
        : 'Senior entrepreneur with experience in various industries.',
    },
    {
      name: 'Linda Susanto',
      position: language === 'id' ? 'Komisaris Independen' : 'Independent Commissioner',
      image: 'https://d64gsuwffb70l.cloudfront.net/697a07882750ca11cca5ba96_1769605199011_3c0531d1.png',
      bio: language === 'id'
        ? 'Profesional dengan latar belakang regulasi dan compliance.'
        : 'Professional with regulatory and compliance background.',
    },
  ];

  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h3 className="text-2xl font-bold text-gray-900 mb-4">
            {language === 'id' ? 'Manajemen & Komisaris' : 'Management & Commissioners'}
          </h3>
          <p className="text-gray-600 max-w-2xl mx-auto">
            {language === 'id' 
              ? 'Tim profesional yang berpengalaman memimpin PEVE menuju kesuksesan'
              : 'Experienced professional team leading PEVE towards success'}
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {management.map((person, index) => (
            <div
              key={index}
              className="bg-white rounded-2xl overflow-hidden shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-300 group"
            >
              <div className="relative h-48 overflow-hidden">
                <img
                  src={person.image}
                  alt={person.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                <div className="absolute bottom-4 left-4 right-4">
                  <h4 className="text-white font-semibold">{person.name}</h4>
                  <p className="text-white/80 text-sm">{person.position}</p>
                </div>
              </div>
              <div className="p-4">
                <p className="text-gray-600 text-sm">{person.bio}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ManagementSection;
