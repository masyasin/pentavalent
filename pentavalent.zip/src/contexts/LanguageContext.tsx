import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

type Language = 'id' | 'en';

interface Translations {
  [key: string]: {
    id: string;
    en: string;
  };
}

const translations: Translations = {
  // Navigation
  'nav.home': { id: 'Beranda', en: 'Home' },
  'nav.about': { id: 'Tentang Kami', en: 'About Us' },
  'nav.business': { id: 'Lini Bisnis', en: 'Business Lines' },
  'nav.partners': { id: 'Mitra', en: 'Partners' },
  'nav.certification': { id: 'Sertifikasi', en: 'Certification' },
  'nav.network': { id: 'Jaringan', en: 'Network' },
  'nav.investor': { id: 'Hubungan Investor', en: 'Investor Relations' },
  'nav.news': { id: 'Berita & Media', en: 'News & Media' },
  'nav.career': { id: 'Karir', en: 'Career' },
  'nav.contact': { id: 'Kontak', en: 'Contact' },
  
  // Hero Section
  'hero.tagline': { id: 'Keunggulan Distribusi Kesehatan Sejak 1968', en: 'Healthcare Distribution Excellence Since 1968' },
  'hero.subtitle': { id: 'Distributor farmasi, alat kesehatan, dan produk consumer health terkemuka di Indonesia dengan jaringan nasional 34 cabang', en: 'Leading pharmaceutical, medical devices, and consumer health distributor in Indonesia with 34 branches nationwide' },
  'hero.cta1': { id: 'Jelajahi Layanan', en: 'Explore Services' },
  'hero.cta2': { id: 'Hubungi Kami', en: 'Contact Us' },
  
  // Stats
  'stats.years': { id: 'Tahun Pengalaman', en: 'Years of Experience' },
  'stats.branches': { id: 'Cabang Nasional', en: 'National Branches' },
  'stats.partners': { id: 'Mitra Principal', en: 'Principal Partners' },
  'stats.provinces': { id: 'Provinsi Terjangkau', en: 'Provinces Covered' },
  
  // About
  'about.title': { id: 'Tentang PT. Penta Valent Tbk', en: 'About PT. Penta Valent Tbk' },
  'about.description': { id: 'Didirikan pada September 1968, PT. Penta Valent Tbk adalah perusahaan distribusi nasional yang bergerak di bidang distribusi produk farmasi, alat kesehatan, dan produk consumer health/kosmetik. Sebagai perusahaan publik yang tercatat di Bursa Efek Indonesia sejak Januari 2023, kami berkomitmen untuk memberikan layanan distribusi terbaik dengan standar kualitas tertinggi.', en: 'Established in September 1968, PT. Penta Valent Tbk is a national distribution company engaged in the distribution of pharmaceutical products, medical devices, and consumer health/cosmetic products. As a public company listed on the Indonesia Stock Exchange since January 2023, we are committed to providing the best distribution services with the highest quality standards.' },
  'about.vision': { id: 'Visi', en: 'Vision' },
  'about.vision.text': { id: 'Menjadi perusahaan distribusi kesehatan terkemuka di Indonesia yang memberikan nilai tambah bagi seluruh pemangku kepentingan.', en: 'To become the leading healthcare distribution company in Indonesia that provides added value for all stakeholders.' },
  'about.mission': { id: 'Misi', en: 'Mission' },
  'about.mission.text': { id: 'Menyediakan layanan distribusi yang handal, efisien, dan berkualitas tinggi untuk produk farmasi, alat kesehatan, dan consumer health di seluruh Indonesia.', en: 'To provide reliable, efficient, and high-quality distribution services for pharmaceutical, medical devices, and consumer health products throughout Indonesia.' },
  
  // Business Lines
  'business.title': { id: 'Lini Bisnis Kami', en: 'Our Business Lines' },
  'business.pharma': { id: 'Distribusi Farmasi', en: 'Pharmaceutical Distribution' },
  'business.pharma.desc': { id: 'Distribusi produk farmasi dengan standar CDOB dan sistem cold chain untuk menjaga kualitas produk.', en: 'Pharmaceutical product distribution with CDOB standards and cold chain system to maintain product quality.' },
  'business.medical': { id: 'Alat Kesehatan', en: 'Medical Devices' },
  'business.medical.desc': { id: 'Distribusi alat kesehatan dengan sertifikasi CDAKB untuk memastikan keamanan dan kualitas produk.', en: 'Medical device distribution with CDAKB certification to ensure product safety and quality.' },
  'business.consumer': { id: 'Consumer Health', en: 'Consumer Health' },
  'business.consumer.desc': { id: 'Distribusi produk consumer health dan kosmetik untuk memenuhi kebutuhan kesehatan masyarakat.', en: 'Consumer health and cosmetic product distribution to meet public health needs.' },
  
  // Network
  'network.title': { id: 'Jaringan Distribusi Nasional', en: 'National Distribution Network' },
  'network.subtitle': { id: 'Menjangkau seluruh Indonesia dengan 34 cabang dan 9 depo strategis', en: 'Reaching all of Indonesia with 34 branches and 9 strategic depots' },
  
  // Certifications
  'cert.title': { id: 'Sertifikasi & Standar Kualitas', en: 'Certifications & Quality Standards' },
  'cert.subtitle': { id: 'Komitmen kami terhadap kualitas dibuktikan dengan berbagai sertifikasi nasional dan internasional', en: 'Our commitment to quality is proven by various national and international certifications' },
  
  // Partners
  'partners.title': { id: 'Mitra Principal Kami', en: 'Our Principal Partners' },
  'partners.subtitle': { id: 'Bermitra dengan perusahaan farmasi terkemuka nasional dan internasional', en: 'Partnering with leading national and international pharmaceutical companies' },
  
  // Investor
  'investor.title': { id: 'Hubungan Investor', en: 'Investor Relations' },
  'investor.subtitle': { id: 'Informasi keuangan dan keterbukaan publik untuk investor', en: 'Financial information and public disclosure for investors' },
  'investor.ipo': { id: 'IPO Januari 2023', en: 'IPO January 2023' },
  'investor.stock': { id: 'Kode Saham: PEVE', en: 'Stock Code: PEVE' },
  
  // News
  'news.title': { id: 'Berita & Media', en: 'News & Media' },
  'news.subtitle': { id: 'Informasi terkini tentang PT. Penta Valent Tbk', en: 'Latest information about PT. Penta Valent Tbk' },
  'news.readmore': { id: 'Baca Selengkapnya', en: 'Read More' },
  
  // Career
  'career.title': { id: 'Karir di PEVE', en: 'Career at PEVE' },
  'career.subtitle': { id: 'Bergabunglah dengan tim kami dan kembangkan karir Anda', en: 'Join our team and develop your career' },
  'career.apply': { id: 'Lamar Sekarang', en: 'Apply Now' },
  
  // Contact
  'contact.title': { id: 'Hubungi Kami', en: 'Contact Us' },
  'contact.subtitle': { id: 'Kami siap membantu Anda', en: 'We are ready to help you' },
  'contact.name': { id: 'Nama Lengkap', en: 'Full Name' },
  'contact.email': { id: 'Email', en: 'Email' },
  'contact.phone': { id: 'Telepon', en: 'Phone' },
  'contact.subject': { id: 'Subjek', en: 'Subject' },
  'contact.message': { id: 'Pesan', en: 'Message' },
  'contact.send': { id: 'Kirim Pesan', en: 'Send Message' },
  'contact.address': { id: 'Alamat Kantor Pusat', en: 'Head Office Address' },
  'contact.hours': { id: 'Jam Operasional', en: 'Operating Hours' },
  
  // Footer
  'footer.about': { id: 'Tentang PEVE', en: 'About PEVE' },
  'footer.quicklinks': { id: 'Tautan Cepat', en: 'Quick Links' },
  'footer.services': { id: 'Layanan', en: 'Services' },
  'footer.contact': { id: 'Kontak', en: 'Contact' },
  'footer.copyright': { id: 'Hak Cipta', en: 'Copyright' },
  'footer.privacy': { id: 'Kebijakan Privasi', en: 'Privacy Policy' },
  'footer.terms': { id: 'Syarat & Ketentuan', en: 'Terms & Conditions' },
  
  // Cookie
  'cookie.message': { id: 'Website ini menggunakan cookies untuk memastikan Anda mendapatkan pengalaman terbaik di website kami.', en: 'This website uses cookies to ensure you get the best experience on our website.' },
  'cookie.accept': { id: 'Terima', en: 'Accept' },
  'cookie.manage': { id: 'Kelola Preferensi', en: 'Manage Preferences' },
  'cookie.policy': { id: 'Kebijakan Cookie', en: 'Cookie Policy' },
};

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>(() => {
    const saved = localStorage.getItem('peve-language');
    return (saved as Language) || 'id';
  });

  useEffect(() => {
    localStorage.setItem('peve-language', language);
  }, [language]);

  const t = (key: string): string => {
    const translation = translations[key];
    if (!translation) return key;
    return translation[language] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
